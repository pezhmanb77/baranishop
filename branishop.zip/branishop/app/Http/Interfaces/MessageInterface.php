<?php

namespace App\Http\Interfaces;


interface MessageInterface
{
    public function fire();
}
